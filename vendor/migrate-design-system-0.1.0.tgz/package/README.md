# @migrate/design-system

Design system da Migrate: tokens (cores, tipografia, espaçamento, raios, sombras, motion, gradientes) e componentes React fiéis à documentação visual do produto. Feito para **React 18+** e **Tailwind CSS v4**.

Uma única fonte de verdade: os valores vivem no `@theme` de `styles.css`. Os componentes só usam os _nomes_ dos tokens (utilitários do Tailwind), nunca valores soltos.

## Três formas de usar

1. **App real** — `npm install @migrate/design-system` (componentes + tokens). Ver abaixo.
2. **Desenvolvimento com IA** — o repo é AI-native: [`CLAUDE.md`](./CLAUDE.md) e [`AGENTS.md`](./AGENTS.md) entregam o DS como contexto para Claude Code / Cursor / Copilot. Documentação em [`docs/`](./docs).
3. **Claude design (artifacts)** — o pacote não roda no sandbox; use [`claude-design/`](./claude-design) (tokens em valor literal/arbitrário + componentes prontos para colar).

### Documentação (`docs/`)

`01-stack` · `02-tokens` · `03-componentes` · `04-acessibilidade` · `05-uso-com-ia` · `06-landing-pages` · `07-apresentacoes` · `08-redes-sociais` · `09-tom-de-voz`.

## Requisitos

- React >= 18
- Tailwind CSS v4 no projeto consumidor
- Fonte **Montserrat** carregada (Google Fonts ou self-host) — o token `--font-sans` já aponta para ela.

## Instalação

```bash
npm install @migrate/design-system
```

Peers (se ainda não tiver): `react`, `react-dom`, `tailwindcss@^4`.

## Configuração

No CSS de entrada do seu app, importe o Tailwind e, **depois**, a folha do design system:

```css
@import 'tailwindcss';
@import '@migrate/design-system/styles.css';
```

Pronto. `styles.css` já:

- registra os tokens como `@theme` (gera as variáveis CSS e os utilitários `bg-primary`, `rounded-card`, `shadow-hover`, ...);
- habilita **dark mode por classe** — coloque `class="dark"` num ancestral (ex.: `<html class="dark">`);
- faz `@source './dist'` para o Tailwind não remover as classes usadas pelos componentes do pacote.

> Se o seu setup não resolver o `@source` de dentro de `node_modules`, adicione manualmente no seu CSS:
> `@source '../node_modules/@migrate/design-system/dist';`

Carregue a Montserrat (exemplo com Google Fonts):

```html
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link
  href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800&display=swap"
  rel="stylesheet"
/>
```

## Uso

```tsx
import { useState } from 'react'
import { Button, Input, Select, Checkbox, Radio, RadioGroup, Card } from '@migrate/design-system'

export function Exemplo() {
  const [regime, setRegime] = useState('')
  const [optou, setOptou] = useState(false)

  return (
    <div className="flex flex-col gap-5">
      <Button variant="primary" onClick={() => {}}>
        Emitir nota
      </Button>
      <Button variant="secondary" isLoading>
        Emitir nota
      </Button>

      <Input
        label="CNPJ"
        required
        placeholder="00.000.000/0000-00"
        hint="Somente números também funciona."
      />
      <Input label="CNPJ" error="CNPJ incompleto. Confira os 14 dígitos." defaultValue="00.000" />

      <Select
        label="Regime tributário"
        placeholder="Selecione um regime"
        value={regime}
        onValueChange={setRegime}
        options={[
          { label: 'Simples Nacional', value: 'simples' },
          { label: 'Lucro Presumido', value: 'presumido' },
          { label: 'Lucro Real', value: 'real' },
          { label: 'MEI', value: 'mei' },
        ]}
      />

      <Checkbox
        label="Optar pelo Simples"
        checked={optou}
        onChange={(e) => setOptou(e.target.checked)}
      />

      <RadioGroup name="regime" value={regime} onValueChange={setRegime}>
        <Radio value="presumido" label="Lucro Presumido" />
        <Radio value="real" label="Lucro Real" />
      </RadioGroup>

      <Card interactive>Conteúdo do card</Card>
      <Card variant="dark">Card sobre fundo azul</Card>
    </div>
  )
}
```

### Dark mode

Os componentes já trazem as variantes `dark:` do design (ex.: botão primário vira `#1A79C2`). Basta um ancestral com `class="dark"`.

## Componentes

**Formulários & ações**

| Componente           | Destaques                                                                      |
| -------------------- | ------------------------------------------------------------------------------ |
| `Button`             | `variant` primary/secondary, `size` sm/md, `isLoading`, `leftIcon`/`rightIcon` |
| `Input`              | `label`, `hint`, `error`, `required`; estados hover/foco/disabled/erro         |
| `Select`             | dropdown próprio, teclado (setas/Enter/Esc), `options`, controlado ou não      |
| `Checkbox` / `Radio` | acessíveis (input nativo + visual estilizado); `RadioGroup` gerencia seleção   |

**Layout & feedback**

| Componente                                 | Destaques                                                            |
| ------------------------------------------ | -------------------------------------------------------------------- |
| `Card`                                     | `variant` light/dark, `interactive` (zoom no hover)                  |
| `Badge`                                    | `tone` primary/accent/success/error/info/muted, `variant` soft/solid |
| `Alert`                                    | `tone` success/error/warning/info, `title`, `onClose`                |
| `Modal`                                    | portal, foco/Esc/overlay, trava de scroll; `size`, `title`, `footer` |
| `Tooltip`                                  | hover/foco, posição no topo (base, sem lib de posicionamento)        |
| `Pagination`                               | 25/50/100/200, botões de página, total de registros                  |
| `Skeleton` / `EmptyState` / `ErrorState`   | os 3 estados de UI exigidos para dados assíncronos                   |
| `Table` + `TableHeader/Body/Row/Head/Cell` | primitivos estilizados (não é data-grid)                             |

Helper de classes exportado: `cn(...)` (clsx + tailwind-merge).

```tsx
import { Alert, Badge, Modal, Pagination, Button, Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '@migrate/design-system'

// Alert
<Alert tone="success" title="Nota emitida" onClose={() => {}}>
  A NFS-e foi transmitida à prefeitura.
</Alert>

// Badge
<Badge tone="success">Ativo</Badge>
<Badge tone="accent" variant="solid">Novo</Badge>

// Modal
<Modal
  isOpen={open}
  onClose={() => setOpen(false)}
  title="Confirmar emissão"
  footer={
    <>
      <Button variant="secondary" className="w-35" onClick={() => setOpen(false)}>Cancelar</Button>
      <Button className="w-35" onClick={confirmar}>Confirmar</Button>
    </>
  }
>
  Deseja emitir a nota fiscal agora?
</Modal>

// Table
<Table>
  <TableHeader>
    <TableRow>
      <TableHead>Documento</TableHead>
      <TableHead>Status</TableHead>
    </TableRow>
  </TableHeader>
  <TableBody>
    <TableRow>
      <TableCell>NFS-e 001</TableCell>
      <TableCell><Badge tone="success">Autorizada</Badge></TableCell>
    </TableRow>
  </TableBody>
</Table>

// Pagination
<Pagination
  page={page}
  pageSize={pageSize}
  totalCount={150}
  totalPages={6}
  onPageChange={setPage}
  onPageSizeChange={setPageSize}
/>
```

## Tokens

- `@migrate/design-system/styles.css` — `@theme` do Tailwind v4 (fonte de verdade) + utilitários de gradiente.
- `@migrate/design-system/tokens.css` — aliases de marca em PT-BR (`--azul-profundo`, `--fs-hero`, ...), pesos, motion, gradientes.
- `@migrate/design-system/tokens.json` — leitura por máquina (ferramentas de design, geração de temas).

### Principais tokens

| Token                    | Valor                         | Utilitário Tailwind           |
| ------------------------ | ----------------------------- | ----------------------------- |
| `--color-primary`        | `#002F4F`                     | `bg-primary` / `text-primary` |
| `--color-primary-medium` | `#074B7F`                     | `bg-primary-medium`           |
| `--color-primary-light`  | `#1A79C2`                     | `bg-primary-light`            |
| `--color-accent`         | `#FF8500`                     | `bg-accent` / `text-accent`   |
| `--color-error`          | `#FF0000`                     | `text-error` / `border-error` |
| `--radius-card`          | `16px`                        | `rounded-card`                |
| `--radius-input`         | `6px`                         | `rounded-input`               |
| `--shadow-hover`         | `0 1px 3px rgba(7,75,127,.3)` | `shadow-hover`                |
| `--font-sans`            | Montserrat                    | `font-sans`                   |

## Storybook (docs vivas)

Playground visual de todos os componentes, com controls e alternador de tema **claro/escuro** na toolbar, além das páginas de **Fundamentos** (Cores e Tipografia) geradas a partir dos tokens.

```bash
npm run storybook         # dev server em http://localhost:6006
npm run build-storybook   # build estático em storybook-static/
```

O Tailwind v4 é injetado no preview via `@tailwindcss/vite` (ver `.storybook/main.ts`); os estilos vêm de `.storybook/preview.css`, que importa o Tailwind + `styles.css` do pacote.

## Desenvolvimento

```bash
npm install
npm run typecheck   # checagem de tipos (inclui as stories)
npm run build       # gera dist/ (tsup: ESM + .d.ts)
npm run format      # prettier
```

Validado nesta máquina: `npm install`, `typecheck`, `build`, `build-storybook` e um smoke test do bundle — todos passando.

## Licença

Uso interno Migrate.
